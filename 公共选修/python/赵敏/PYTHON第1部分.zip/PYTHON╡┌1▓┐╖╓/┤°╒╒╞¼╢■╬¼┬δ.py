from PIL import Image #PIL(Python Image Lib)模块，调用库
import qrcode
qr = qrcode.QRCode(
    version=2,
    error_correction=qrcode.constants.ERROR_CORRECT_H,
    box_size=10,
    border=1)
#version参数是（1-40）的整数，该参数用来控制二维码的尺寸
#qrcode.constants.ERROR_CORRECT_H该常量表示误差率低于30%(包含30%)
#box_size参数用来控制二维码的每个单元(box)格有多少像素点
#border参数用控制每条边有多少个单元格(默认值是4，这是规格的最小值)
qr.add_data("http://piclass.cn")
qr.make(fit=True)

img = qr.make_image() #创建二维码（返回im类型的图片对象） 

#模式“RGBA”为32位彩色图像，它的每个像素用32个bit表示，其中24bit表示红色、绿色和蓝色三个通道，另外8bit表示alpha通道，即透明通道。
#下面代码将模式为“RGB”的图像转换为“RGBA”图像。
img = img.convert("RGBA")

icon = Image.open("time.png") #用于填充的图片 

img_w, img_h = img.size #img.size返回一个包含两个数的元组
factor = 4
size_w = int(img_w / factor)
size_h = int(img_h / factor)

icon_w, icon_h = icon.size
if icon_w > size_w:
    icon_w = size_w
if icon_h > size_h:
    icon_h = size_h
icon = icon.resize((icon_w, icon_h), Image.ANTIALIAS)
#设置缩放图片的质量（PIL.Image.NEAREST：最低质量， PIL.Image.BILINEAR：双线性，PIL.Image.BICUBIC：三次样条插值，Image.ANTIALIAS：最高质量）
w = int((img_w - icon_w) / 2) #位置信息
h = int((img_h - icon_h) / 2) #位置信息
img.paste(icon, (w, h), icon)

img.save("test3.png")
