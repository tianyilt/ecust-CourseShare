import webbrowser
chromePath=r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
webbrowser.register('chrome',None,webbrowser.BackgroundBrowser(chromePath))  
webbrowser.get('chrome').open('www.baidu.com',new=1,autoraise=True)
