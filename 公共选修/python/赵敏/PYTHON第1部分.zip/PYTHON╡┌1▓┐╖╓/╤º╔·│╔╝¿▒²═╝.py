import matplotlib.pyplot as plt
labels="math","english","chinese"
colors=["yellow","red","blue"]
size=[]
math=int(input("请输入数学成绩："))
english=int(input("请输入英语成绩："))
chinese=int(input("请输入语文成绩："))
size.append(math)
size.append(english)
size.append(chinese)
explode=(0,0.1,0)
plt.pie(size,explode=explode,labels=labels,colors=colors,autopct="%1.1f%%",shadow=True, startangle=90)
plt.show()
