import qrcode
qr=qrcode.QRCode()
qr.add_data("I like Python")
qr.make(fit=True)
img=qr.make_image()
img.save('test1.jpg')
