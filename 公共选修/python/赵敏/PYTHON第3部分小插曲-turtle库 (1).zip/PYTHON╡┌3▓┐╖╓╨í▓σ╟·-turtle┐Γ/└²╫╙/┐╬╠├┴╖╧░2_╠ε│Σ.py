from turtle import *
pencolor("yellow")
pensize(10)
fillcolor("red")
begin_fill()
circle(60)
end_fill()
