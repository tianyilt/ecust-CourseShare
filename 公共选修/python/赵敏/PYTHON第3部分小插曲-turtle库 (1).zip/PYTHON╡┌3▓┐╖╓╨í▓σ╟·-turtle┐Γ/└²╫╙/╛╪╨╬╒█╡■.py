from turtle import *
speed(100)
pencolor("red")
for x in range(1,500,7):
    forward(x)
    left(91)
