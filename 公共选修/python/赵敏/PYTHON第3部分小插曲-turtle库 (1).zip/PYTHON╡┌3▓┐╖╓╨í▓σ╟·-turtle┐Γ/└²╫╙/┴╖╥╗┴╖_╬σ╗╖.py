import time
import os
import turtle
def circle(color,x,y):
    turtle.penup()
    turtle.pencolor(color)
    turtle.goto(x,y)
    turtle.pendown()
    for i in range(90):#开始画圆
        turtle.right(4)
        turtle.forward(4)
    turtle.penup()

turtle.pensize(10)
turtle.speed(10)#设置绘制的速度：“fastest”: 0；“fast”: 10；“normal”: 6；“slow”: 3；“slowest”: 1
circle('blue',-150,100)
circle('black',0,100)
circle('red',150,100)
circle('yellow',-75,50)
circle('green',75,50)

time.sleep(10) 
os._exit(1)#os._exit()会直接将python程序终止，之后的所有代码都不会继续执行。exit(0)：无错误退出,exit(1)：有错误退出,退出代码是告诉解释器的（或操作系统）
