from turtle import *
pencolor("red")
for x in range(100):
    circle(x)
    left(90)
