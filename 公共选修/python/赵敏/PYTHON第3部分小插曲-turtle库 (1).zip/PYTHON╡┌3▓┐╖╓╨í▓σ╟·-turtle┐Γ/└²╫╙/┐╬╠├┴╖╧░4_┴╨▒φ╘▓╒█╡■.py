from turtle import *
pencolor("red")
bgcolor("black")
speed(100)
colors=["red","yellow","blue","green"]
for x in range(100):
    pencolor(colors[x%4])
    circle(x)
    left(91)
