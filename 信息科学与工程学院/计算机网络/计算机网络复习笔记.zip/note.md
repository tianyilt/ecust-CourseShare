## Link layer

* 以太网规定了一个最短帧长64字节，即512比特
* 争用期$2\tau=51.2 \mu s$ ，电磁波在1km电缆的传播时延约为$5\mu s$
* 退避算法：重传应退后的时间应为r倍的争用期
* 碰撞后，除了立即停止发送数据外，还要继续发送32bit或者48bit的人为干扰信号。
* 帧间最小间隔为$9.6\mu s$ (96比特时间)

## IP

* The routing table can also be updated when ICP "redirect" messages are received.
* steps that IP performs when it searches its routing table.
  1. Search for a matching host address.
  2. Search for a matching network address.
  3. Search for a default entry. (With the network ID of 0)
* Host are not supposed to forward IP datagrams unless they have been specifically configured as a router.



## TCP

* TCP control the best sized chunks to send, where UDP datagram controlled by application

* TCP does not interpret the contents of the bytes at all.
* When connection is established, ack field is always set and ACK is always=1
* There is no means for negatively acknowledging a segment, we can only do duplicate acknowledgments by sending same ack field.
* A SYN/FIN consumes one sequence number.
* The ISN (initial sequence number) should be viewed as a 32-bit counter that increments by one every 4 microseconds in order to prevent misinterpreted as part of an existing connection.
* Connection often initiated by the client(interactive user), as well as terminated.



