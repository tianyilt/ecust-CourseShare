# coding=utf-8
import web
import calendar
from sympy import *
import qrcode
import time
import pymysql
import sqlite3

# 路径映射到类
urls = (
        '/','Mulit',
        '/calendar.html','Calendar',
        '/math.html','Math',
        '/qrcode1.html','Qrcode1',

        '/multi.html','Mulit',
        '/leave1.html','Leave1',
        '/leave2.html','Leave2',

        '/leave3.html','Leave3',
        '/leave4.html','Leave4',
         '/score.html','Score',
        )

def sql_select(text):
    conn = sqlite3.connect('school.db')


    #conn=pymysql.connect(host='data.piclass.cn',user="root",passwd="piclass",db="webpy",port=3306,charset='utf8')

    cur = conn.cursor()
    cur.execute(text)
    res=cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    return res


def sql_write(text):
    conn = sqlite3.connect('school.db')
    #conn=pymysql.connect(host='data.piclass.cn',user="root",passwd="piclass",db="webpy",port=3306,charset='utf8')
    cur = conn.cursor()
    cur.execute(text)
    cur.close()
    conn.commit()
    conn.close()


# 模板渲染(render:渲染) 括号里的 templates 指的是模板所处的目录
render = web.template.render('templates')

# 构造index类 
class Calendar:
    def GET(self):
        return render.calendar("","")
    def POST(self):
        data=web.input()
        year=int(data["year"])
        result=calendar.calendar(year)
        return render.calendar(year,result)

class Math:
    def GET(self):
        return render.math("x**2",['','','',''])
    def POST(self):
        data=web.input()
        expression=data["expression"]
       
        result=[
            diff(expression),
            integrate(expression),
            solve(expression)
            ]
        return render.math(expression,result)

class Qrcode1:
    def GET(self):
        return render.qrcode1('','')
    def POST(self):
        data=web.input()
        word=data["word"]
        qr=qrcode.QRCode()
        qr.add_data(word)
        qr.make(fit=True)
        img=qr.make_image()
        
        fname="%s.jpg"%(int(time.time()))
        img.save("./static/"+fname)
        
        return render.qrcode1(word,fname)

class Mulit:
    def GET(self):
        return render.mulit('')

    def POST(self):
        data = web.input()
        text = data["text"]
        K = int(data["K"])
        result=""
        print(data)
        #加密
        if "b1" in data:
            result += u"密文："
            for each in text:
                result+=chr(ord(each)+K)
        else:
            result += u"原文："
            for each in text:
                result+=chr(ord(each)-K)
        return render.mulit(result)

tableData=[
        ['001','Tiger','2017-01-22','2017-03-01','无'],
        ['002','Lion','2017-01-8','2017-03-02','无'],
        ['003','Cat','2017-01-10','2017-03-04','无'],
        ['004','Dog','2017-01-10','2017-03-04','无']]

class Leave1:
    def GET(self):
        
        return render.leave1(tableData)

class Leave2:
    def GET(self):
        return render.leave2()
    def POST(self):
        data= web.input()
        username,name,start,end,notice=data["username"],data["name"],data["start"],data["end"],data["notice"]
        tableData.append([username,name,start,end,notice])
        return web.redirect('/leave1.html')


class Leave3:
    def GET(self):
        sql="select username,name,start,end,notice from leave_school"
        tableData=sql_select(sql)
        return render.leave3(tableData)

class Leave4:
    def GET(self):
        return render.leave4()
    def POST(self):
        data= web.input()
        username,name,start,end,notice=data["username"],data["name"],data["start"],data["end"],data["notice"]
        sql=u"insert into leave_school(username,name,start,end,notice) values('%s','%s','%s','%s','%s')"%(username,name,start,end,notice)
        sql_write(sql)
        return web.redirect('/leave3.html')

class Score:
    def GET(self):
        sql="select score,count(*) from score group by score order by score;"
        data=sql_select(sql)
        result=[]
        for t in data:
            result.append(t[1])
        print(result)
        return render.score(result)
      
      


web.config.debug = True
app = web.application(urls, globals())

if web.config.get('_session') is None:
    session = web.session.Session(app, web.session.DiskStore('sessions'), {'count': 0})
    web.config._session = session
else:
    session = web.config._session

if __name__ == "__main__":
   app.run()
