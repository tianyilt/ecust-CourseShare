import sqlite3
conn=sqlite3.connect("school.db")
SQL='''update student set name="张三",age=25 where code='9001' '''                   
conn.execute(SQL)
conn.commit()
conn.close()


    
    
