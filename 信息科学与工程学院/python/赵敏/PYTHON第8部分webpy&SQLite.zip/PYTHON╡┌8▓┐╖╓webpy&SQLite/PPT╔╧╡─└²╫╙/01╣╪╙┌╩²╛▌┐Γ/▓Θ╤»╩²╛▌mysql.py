import pymysql
conn=pymysql.connect(host='127.0.0.1',port=3306,user='root',passwd='123456',db='test')
cu = conn.cursor()
SQL='''select * from student'''                   
cu.execute(SQL)
result=cu.fetchall()
for each in result:
    print(each[0],each[1])
cu.close()

    
    
