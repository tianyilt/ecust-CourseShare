import pyodbc
conn=pyodbc.connect('DSN=student')
cu = conn.cursor()
SQL='''select * from student'''                   
cu.execute(SQL)
result=cu.fetchall()
for each in result:
    print(each[0],each[1])
cu.close()

    
    
