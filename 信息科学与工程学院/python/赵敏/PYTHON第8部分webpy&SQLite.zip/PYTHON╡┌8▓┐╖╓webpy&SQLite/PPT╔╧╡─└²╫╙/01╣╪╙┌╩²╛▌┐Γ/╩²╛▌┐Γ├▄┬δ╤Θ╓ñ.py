# coding=utf-8
from tkinter import *
import sqlite3

root = Tk()
root.title("密码验证")
root.geometry("200x150")
def verify():
    found=0
    conn=sqlite3.connect("school.db")
    cu=conn.cursor()
    type(cu)
    SQL='''select * from user'''                   
    cu.execute(SQL)
    result=cu.fetchall()

    for each in result:
        if(E1.get()==each[0] and E2.get()==str(each[1])):  
            print("身份正确，欢迎进入")
            found=1
            break
    if found==0:
        print("身份错误，请重试")
    conn.close()
    
L1 = Label(root, text="用户名：")
L1.place(x=10,y=10)
E1 = Entry(root, bd =5,font=12,width=15)
E1.place(x=60,y=10)
L2=Label(root, text="密   码：")
L2.place(x=10,y=60)
E2 = Entry(root, bd =5,font=12,width=15,show="*")
E2.place(x=60,y=60)
B1 = Button(root, text="验证密码信息",width=15,command=verify)
B1.place(x=60,y=100)
root.mainloop()
