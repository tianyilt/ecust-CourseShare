import sqlite3
conn=sqlite3.connect("school.db")
SQL='''insert into student (code, name,
                          age) values('9001', '张芳' , 20)'''                   
conn.execute(SQL)
conn.commit()
conn.close()

    
    
