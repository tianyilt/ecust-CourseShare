import sqlite3
conn=sqlite3.connect("school.db")
SQL='''
create table student3(
          code text not null primary key,
          name text,
          age int)
'''                   
conn.execute(SQL)
conn.commit()
conn.close()

    
    
