import sqlite3
conn=sqlite3.connect("school.db")
SQL='''delete from student where code='9001' '''                   
conn.execute(SQL)
conn.commit()
conn.close()


    
    
