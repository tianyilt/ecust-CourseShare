import sqlite3
conn=sqlite3.connect("school.db")
SQL='''
drop table student1
'''                   
conn.execute(SQL)
conn.commit()
conn.close()

    
    
