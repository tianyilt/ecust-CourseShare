#coding=utf-8
import web
urls = ('/','index',
        "/blog.html","blog",
        )
render = web.template.render('templates')
class index:
    def GET(self):
        title="Garfield 's Zone"
        return render.index(title)
    
class blog:
    def GET(self):
        articles=[
            ["Python基础教程1","http://www.runoob.com/python/python-tutorial.html",1],
            ["Python基础教程2","http://www.runoob.com/python/python-tutorial.html",0],
            ["Python基础教程3","http://www.runoob.com/python/python-tutorial.html",1]
            ]
        
        return render.blog(articles)  
            
if __name__ == "__main__": 
    app = web.application(urls, globals())    
    app.run()
