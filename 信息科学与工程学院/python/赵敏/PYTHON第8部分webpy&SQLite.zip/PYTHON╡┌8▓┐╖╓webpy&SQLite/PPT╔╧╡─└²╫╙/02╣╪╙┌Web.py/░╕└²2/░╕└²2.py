#coding=utf-8
import web
urls = ('/','index',)
render = web.template.render('templates')

class index:
    def GET(self):
        title="Hello！ I'm your teacher,I am Catherine!"
        return render.index1(title)   
if __name__ == "__main__":   
    app = web.application(urls, globals())    
    app.run()
