#coding=utf-8
import web
urls = ('/','index1',
        "/calculator.html","calculator",
        )
render = web.template.render('templates')
class index1:
    def GET(self):
        title="我的网页"
        return render.index(title)
    
class calculator:
    def GET(self):
        expression,answer="",""
        return render.calculator(expression,answer)
        
    def POST(self):
        data=web.input()#表单提交上来的数据(key是html代码中的name)，{"expression":"xxx","answer":"xxx"}
        expression=data["expression"]
        answer=eval(expression)
        return render.calculator(expression,answer)
if __name__ == "__main__":    
    app = web.application(urls, globals())    
    app.run()
