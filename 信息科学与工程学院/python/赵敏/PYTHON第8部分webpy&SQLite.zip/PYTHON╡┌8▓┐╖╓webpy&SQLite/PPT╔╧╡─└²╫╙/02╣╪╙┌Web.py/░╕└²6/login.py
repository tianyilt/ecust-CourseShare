#!/usr/bin/env python
#coding=utf-8
import web
from web import form

urls = (
	'/','Index',
	'/login','Login',)

render = web.template.render("templates")

allowed = (('admin','123456'),('111111','111111'))

web.config.debug = False
app = web.application(urls, locals())
session = web.session.Session(app, web.session.DiskStore('sessions'))


class Index:
	def GET(self):
		if session.get('logged_in',False):#session.get("logged_in",False)就是在session里面找logged_in,如果找不到就返回后面的参数。
		    return '<h1>Login Success!!!</h1>'
		raise web.seeother('/login') #处理完用户输入后，跳转到其他页面
#这里必须要用raise web.seeother('/login')才可以，直接用程序跑下来的结果就是：
#如果是seeother的话，url会发生变化，变成http://localhost:8080/login
#如果是render.login()的话，直接跳到login.html页面

class Login:
	def GET(self):
		return render.login()
	def POST(self):
		message = web.input()
		username = message.get('username')
		passwd = message.get('passwd')
		if (username,passwd) in allowed:
			session.logged_in = True
			web.setcookie('system_mangement', '', 60) #(name, value, timeout),过期时间以秒为单位
			raise web.seeother('/')
		else:
			return '<h1>Login Error!!!</h1></br><a href="/login">Login</a>'

if __name__ == '__main__':
	app.run()
