i=1
while i<10:
    if i*i*i>100:
        break
    else:
        print "棱长为",i,"的正方体的体积为：",i*i*i
    i=i+1
