number=100
while number<1000:
    first=number/100
    second=(number-first*100)/10
    third=number%10
    if number==first**3+second**3+third**3:
        print number, " is flower" 
    number=number+1
