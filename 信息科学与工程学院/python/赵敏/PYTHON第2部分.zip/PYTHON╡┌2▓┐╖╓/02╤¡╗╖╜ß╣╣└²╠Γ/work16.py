sum=0
i=0
while i<=100:
    sum=sum+i
    i+=1
print "1-100之和为：",sum
