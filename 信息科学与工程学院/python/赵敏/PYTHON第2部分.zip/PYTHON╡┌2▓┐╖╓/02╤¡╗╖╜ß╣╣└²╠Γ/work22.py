from random import *
ranNumber=randint(0,100)
myNumber=input("请输入一个0到100的数字：")
while 0<myNumber<100:
    if ranNumber<myNumber:
        print "您猜得太大了"
        myNumber=input("请输入一个0到100的数字：")
    elif ranNumber>myNumber:
        print "您猜得太小了"
        myNumber=input("请输入一个0到100的数字：")
    else:
        print "恭喜您猜对了"
        break
    
else:
    print "您的输入有误"
