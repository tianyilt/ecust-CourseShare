import matplotlib.pyplot as plt
print("欢迎进入某班级成绩管理系统！")
print("系统设计与开发人员：某某某！")
print("版本信息：第二版（试运行）！")
print("************************")
print("*1.计算总分    2.求最高分*")
print("*3.划分等级    4.退出*")
print("************************")
math=float(input("请输入您的数学成绩："))
chinese=float(input("请输入您的语文成绩："))
english=float(input("请输入您的英语成绩："))
choice=int(input("请输入您的选择："))
mysum=math+chinese+english
while 1<=choice<=4:
    if choice==1:
        print("您的总成绩为：%f" % mysum)
    elif choice==2:
        if math<chinese:
          maxscore=chinese
        else:
          maxscore=math
        if maxscore<english:
          maxscore=english
        print(maxscore)
    elif choice==3:
        if mysum>270:
            print("A类成绩")
        elif mysum>240:
            print("B类成绩")
        elif mysum>180:
            print("C类成绩")
        else:
            print("D类成绩")
    elif choice==4:
        opt = input("您确实要退出吗？(Y/N)")
        if opt == 'Y':
            break;
    choice=int(input("请输入您的选择："))    
