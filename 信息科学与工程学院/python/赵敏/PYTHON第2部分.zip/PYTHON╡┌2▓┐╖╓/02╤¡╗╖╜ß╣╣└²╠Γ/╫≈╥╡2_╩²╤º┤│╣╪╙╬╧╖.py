import random
score=0
count=1
while count<=10:
    x=random.randint(0,100)
    y=random.randint(0,100)
    print(x,"+",y,"=",end="")
    answer=int(input(""))
    if x+y==answer:
        print("恭喜您答对了")
        score=score+1
    else:
        print("请继续努力")
    count=count+1
print("您的得分是：",score,end="")
if score>8:
    print("恭喜您，闯关成功！")
else:
    print("好遗憾，没有成功！")
