n=input("请输入一个正整数：")
factorial=1
i=1
while i<=n:
    factorial=factorial*i
    i=i+1
print "1-100之积为：",factorial
