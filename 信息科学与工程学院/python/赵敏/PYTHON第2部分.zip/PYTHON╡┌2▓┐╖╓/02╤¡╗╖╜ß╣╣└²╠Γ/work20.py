i=0
sum=0
print "1-100之间的偶数之和为："
while i<=100:
    i=i+1
    if i%2==1:
        continue
    else:
         sum=sum+i
print sum
