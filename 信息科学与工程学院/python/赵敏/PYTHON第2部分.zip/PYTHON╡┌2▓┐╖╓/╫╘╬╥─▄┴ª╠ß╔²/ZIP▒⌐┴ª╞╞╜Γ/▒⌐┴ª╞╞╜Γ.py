import zipfile
zFile=zipfile.ZipFile("secret.zip")
passwd=0
while 1:
    try:
        try_passwd=str(passwd).encode() 
        zFile.extractall(pwd=try_passwd)
        print("password is %s"%try_passwd)
        break
    except:
        passwd+=1

