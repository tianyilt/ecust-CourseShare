import random
data =random.randint(500,3072)
min = 500
max = 3072
count = 1
#print(data,data//1000,data - 1000*data//1000,(data - 1000*data//1000)//100)
third = (data - 1000*(data//1000))//100

print("___  %d  ___  ___\n\n"%third)

if third <= 4:
    min = 1000 + third *100
else:
    min = third * 100

if third !=0:
    max = 2099+third*100
    
while 1:
    print("当前范围%d,%d"%(min,max))
    tel = input("%d:请输入您的手机号:"%count)
    guess = int(input("%d:请猜测价格:"%count)) 

    if guess < data : 
        print("%d低了\n\n"%guess)
        if guess > min:
            min = guess
            
    elif guess > data : 
        print("%d高了\n\n"%guess)
        if guess <max:
             max = guess
             
    elif guess == data:
        if count==1:
            print("第1个人获得%dMB"%data)
        else:
            print("第1个人获得%dMB"%(data/2))
            i = 2
            while i < count:
                print("第%d个人获得%dMB"%(i,data/4/(count-1)))
                i += 1
            print ("第%d个人获得%dMB"%(count,data/4))
            break
    count +=1
  
        
        
        
    
        
