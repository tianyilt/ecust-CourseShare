#coding=utf-8
student_answer=["A","A ","a","a","AA","a  \n"]
for answer in student_answer:
    if answer.replace("\n", "").strip(" ").upper() == "A":
        print(answer, "True")
    else:
        print(answer, "False")
