print("李白是_____诗人(朝代)")
answer=input("请输入您的答案")  #唐朝，唐代，唐朝的，唐代的
if "唐"in answer:
    print("Right")
else:
    print("Error")
