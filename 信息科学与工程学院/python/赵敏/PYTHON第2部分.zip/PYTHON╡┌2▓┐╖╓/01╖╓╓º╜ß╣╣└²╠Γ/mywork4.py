firstNumber =input('请输入第一个数字:')
secondNumber=input('请输入第二个数字:')
thirdNumber=input('请输入第三个数字:')
if firstNumber<secondNumber:
    firstNumber,secondNumber=secondNumber,firstNumber
if firstNumber<thirdNumber:
    firstNumber,thirdNumber=thirdNumber,firstNumber
if secondNumber<thirdNumber:
    secondNumber,thirdNumber=thirdNumber,secondNumber
print "从大到小的排序结果是：%d,%d,%d" %(firstNumber,secondNumber,thirdNumber)

    
