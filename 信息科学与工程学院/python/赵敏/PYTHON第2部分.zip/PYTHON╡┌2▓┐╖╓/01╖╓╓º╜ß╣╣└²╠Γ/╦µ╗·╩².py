import random
num=random.randint(0,100)
guess=int(input("请输入您的猜测："))
if num>guess:
    print("您猜的太小了")
elif num<guess:
    print("您猜的太大了")
else:
    print("您猜的正好！")
