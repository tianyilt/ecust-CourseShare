intFlower=input("请输入一个三位数字：")
firstNumber=intFlower/100
secondNumber=(intFlower-firstNumber*100)/10
thirdNumber=intFlower%10
if intFlower==firstNumber**3+secondNumber**3+thirdNumber**3:
    print "%d is flower" %intFlower
else:
    print "%d isn't flower" %intFlower
