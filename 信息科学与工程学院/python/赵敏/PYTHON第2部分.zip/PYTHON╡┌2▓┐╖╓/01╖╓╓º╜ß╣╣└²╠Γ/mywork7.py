from math import *
a=input("请输入a的值：")
b=input("请输入b的值：")
c=input("请输入c的值：")
d=b*b-4*a*c
if d<0:
     x1 = (-b+complex(0,1)*sqrt((-1)*d))/(2*a)
     x2 = (-b-complex(0,1)*sqrt((-1)*d))/(2*a)
     print x1,x2
elif d>0:
    x1=(-b+sqrt(b*b-4*a*c))/(2*a)
    x2=(-b-sqrt(b*b+4*a*c))/(2*a)
    print x1,x2
else:
    x1=x2=-b/(2*a)
    print x1,x2
