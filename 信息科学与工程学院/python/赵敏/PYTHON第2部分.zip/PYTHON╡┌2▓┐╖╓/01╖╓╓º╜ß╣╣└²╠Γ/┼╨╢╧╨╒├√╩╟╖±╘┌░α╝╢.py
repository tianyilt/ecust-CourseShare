aList=["赵一一","钱二二","孙三三","李四四","周五五"]
name=input("请输入您的姓名：")
if name in aList:
    print("%s是我们班同学"% name)
else:
    print("%s不是我们班同学"% name)
