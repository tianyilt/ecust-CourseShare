found=0
fobj = open('student.txt', 'r')
while found==0:
    myCode=input("请输入您的学号：")
    for eachLine in fobj:     
        if eachLine[:8]==myCode:
            print("欢迎%s同学进入！" % eachLine[9:-1])
            found=1
            break
    if found==0:
        print("很遗憾，您没有权限！")
    fobj.seek(0)#一定要注意，回到文件头，1是当前位置，2是文件尾
fobj.close()

