fobj = open('student.txt', 'a+')
print("请输入学生信息（以空学号结束输入）")
num = input("学号：")
name = input("姓名：")
while num !='':
    #fobj.write(num)
    #fobj.write(" ")
    #fobj.write(name)
    #fobj.write("\n")
    fobj.writelines([num,' ',name,'\n'])
    num = input("学号：")
    name = input("姓名：")
fobj.close()

