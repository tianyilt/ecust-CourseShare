try:
    filename = input("请输入文件名:")
    hFile = open(filename,"r")
    num1=int(hFile.readline())
    num2=int(hFile.readline())
    num3=num1/num2
except IOError:
    print("文件打开失败")
except ZeroDivisionError:
    print("除数为0")
else:
    print(num3)
    hFile.close()
