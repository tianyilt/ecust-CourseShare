# coding=utf-8
from tkinter import *

root = Tk()
root.title("密码验证")
root.geometry("300x50")
L1 = Label(root, text="用户名：")
L1.place(x=10,y=10)
E1 = Entry(root, bd =5,font=12,show="*",width=15)#show:设置显示内容是否为”*”
E1.place(x=60,y=10)

root.mainloop()
