import a
def hello_world():
    print(a.gl_1,a.gl_2)

if __name__ == '__main__' :
    hello_world()
