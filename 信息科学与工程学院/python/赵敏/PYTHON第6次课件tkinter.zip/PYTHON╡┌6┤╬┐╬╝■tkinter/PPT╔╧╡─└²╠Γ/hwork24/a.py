gl_1 = 'Good'
gl_2 = 'morning'
