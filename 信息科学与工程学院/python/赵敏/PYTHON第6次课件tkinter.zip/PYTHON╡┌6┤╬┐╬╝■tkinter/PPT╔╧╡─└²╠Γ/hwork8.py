#coding=utf-8
from tkinter import *
def cal():
    E2.insert(0,eval(E1.get()))
    E2.insert(END,eval(E1.get()))
    
root = Tk()
root.title("小型计算器")
root.geometry("250x150")
L1 = Label(root, text="公式：")
L1.place(x=10,y=10)
E1 = Entry(root, bd =1,font=12,width=15)
E1.place(x=60,y=10)
L2=Label(root, text="结果：")
L2.place(x=10,y=60)
E2 = Entry(root, bd =1,font=12,width=15)
E2.place(x=60,y=60)
B1 = Button(root, text="计算",width=15,command=cal)
B1.place(x=70,y=100)
root.mainloop()
