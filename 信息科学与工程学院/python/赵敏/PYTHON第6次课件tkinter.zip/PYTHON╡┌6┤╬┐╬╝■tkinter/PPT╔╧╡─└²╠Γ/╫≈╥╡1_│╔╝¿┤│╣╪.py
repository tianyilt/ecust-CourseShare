#-*- encoding=UTF-8 -*-
__author__ = 'fyby'
from tkinter import *
from random import *
root = Tk()
root.title("数字闯关游戏")
root.geometry("300x330")

#如果你不熟练，我给出一个例子，仿照写出函数medium和hard
def easy():
    count1=0
    for i in range(10):
        x=randint(0,10)
        y=randint(0,10)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count1=count1+1
    print("您的得分为:",count1)
    if count1>=8:
        print("恭喜您闯关成功，请进入下一关！")
        
    else:
        print("很遗憾未成功，请重试！")
def medium():





    
def hard():




    

    
#简单题目，控件生成



#中等题目，控件生成



#困难题目，控件生成


 
root.mainloop()
