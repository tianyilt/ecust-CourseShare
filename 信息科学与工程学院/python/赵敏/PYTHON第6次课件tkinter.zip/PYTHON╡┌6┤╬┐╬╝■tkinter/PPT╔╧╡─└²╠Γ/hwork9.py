# coding=utf-8
from tkinter import *
from tkinter.messagebox import *
def sayok():
    #root.destroy()如果有这句有什么作用？
    import hwork_confirm
root = Tk()
root.title("评分游戏")
root.geometry("300x300")

   
aLabel = Label(root,text="欢迎进入评分游戏",font='隶书 20',width=20,height=5,fg='red')
aLabel.place(x=10,y=10)

c1=Button(root,text='开始游戏',font ='20',height=2,width=22,command=sayok)
c1.place(x=40,y=150)

c1=Button(root,text='退出游戏',font ='20',height=2,width=22,command=root.quit)
c1.place(x=40,y=210)

root.mainloop()

