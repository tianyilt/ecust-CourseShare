# coding=utf-8
#显示Checkbutton的值
from tkinter import *
root = Tk()
#将一整数与Checkbutton的值绑定，选择Checkbutton，将打印出当前所选的值
v1 = IntVar()
v2 = IntVar()
def verify():
    if v1.get()==1 and v2.get()==1:
        print("您喜欢体育和音乐")
    elif v1.get()==1:
        print("您喜欢体育，不喜欢音乐")
    elif v2.get()==1:
        print("您喜欢音乐，不喜欢体育")
    else:
        print("您既不喜欢体育又不喜欢音乐")
C1=Checkbutton(root,variable = v1,text = '体育')
C1.pack()
C2=Checkbutton(root,variable = v2,text = '音乐')
C2.pack()
B1=Button(root,text='确定 ',command=verify)
B1.pack()
root.mainloop()
