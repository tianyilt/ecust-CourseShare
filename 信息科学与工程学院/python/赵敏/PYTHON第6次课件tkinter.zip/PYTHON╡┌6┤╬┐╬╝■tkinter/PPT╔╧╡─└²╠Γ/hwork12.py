# coding=utf-8
from tkinter import *
def hello():
    print("hello,everyone!")

root = Tk()
menubar=Menu(root)
menubar.add_command(label="欢迎",command=hello)
menubar.add_command(label="退出",command=root.quit)
# display the menu
root.config(menu=menubar)
root.mainloop() 
