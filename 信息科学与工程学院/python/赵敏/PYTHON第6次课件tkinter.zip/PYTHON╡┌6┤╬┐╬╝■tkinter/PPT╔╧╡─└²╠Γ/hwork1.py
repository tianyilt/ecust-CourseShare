# coding=utf-8
from tkinter import *
root = Tk()
root.title("评分游戏")
root.geometry("300x200")
aLabel = Label(root,text="欢迎进入评分游戏",font='隶书 20',width=20,height=5,fg='red',bg='yellow')
aLabel.place(x=10,y=10)
root.mainloop() 
