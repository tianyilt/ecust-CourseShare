from tkinter import *
root = Tk()
root.title("一个实例")
root.geometry('200x200')
Label1 = Label(root,text='test',font="20",fg="red",bg="yellow")
Label1.pack()
Label2 = Label(root,text='test',font="20",fg="blue",bg="yellow")
Label2.pack()
