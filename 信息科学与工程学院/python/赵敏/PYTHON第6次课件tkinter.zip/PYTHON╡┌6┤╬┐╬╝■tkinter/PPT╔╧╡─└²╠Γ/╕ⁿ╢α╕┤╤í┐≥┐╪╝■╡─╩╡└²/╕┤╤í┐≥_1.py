from tkinter import *
root = Tk()
root.geometry("200x200")

def run():
    if checkVar1.get()==0 and checkVar2.get()==0 and checkVar3.get()==0 and checkVar4.get()==0:
        s = '您没有选择任何爱好的项目'
    else:
        if checkVar1.get()==1:
            s1='足球'
        else:
            s1=''
        if checkVar2.get()==1:
            s2='篮球'
        else:
            s2=''
        if checkVar3.get()==1:
            s3='游泳'
        else:
            s3=''
        if checkVar4.get()==1:
            s4='田径'
        else:
            s4=''
    s = "您选择了%s、%s、%s、%s" % (s1,s2,s3,s4)
    LbVar2.set(s)
    
        
Lb1 = Label(root,text='请选择您的爱好项目')
Lb1.pack()

checkVar1 = IntVar()
checkVar2 = IntVar()
checkVar3 = IntVar()
checkVar4 = IntVar()
LbVar2 = StringVar()

Check1 = Checkbutton(root,text='足球',variable=checkVar1)
Check1.pack()

Check2 = Checkbutton(root,text='篮球',variable=checkVar2)
Check2.pack()

Check3 = Checkbutton(root,text='游泳',variable=checkVar3)
Check3.pack()

Check4 = Checkbutton(root,text='田径',variable=checkVar4)
Check4.pack()

btn1 = Button(root,text='OK',command=run)
btn1.pack()

Lb2 = Label(root,textvariable=LbVar2)
Lb2.pack()

root.mainloop()
