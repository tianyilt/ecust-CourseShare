from tkinter import *
#利用列表和字典实现
root = Tk()
root.geometry("200x250")

#复选框实例可以利用select()、deselect()和toggle()方法对其进行选中，清除选中和反选操作
def resetcheck():
    checkVar1.set("0")
    checkVar2.set("0")
    checkVar3.set("0")
    checkVar4.set("0")

    
def ok():
    dic = {0:'足球',1:"篮球",2:"游泳",3:"田径"}
    chknum = [checkVar1.get(),checkVar2.get(),checkVar3.get(),checkVar4.get()]
    s=''
    for i in range(4):
        if chknum[i] == 1:#i表明是第几项的get值为1，对应的就是字典的第几项被选中
            s += dic[i]
    if s=='':
        s = "您没有选择任何爱好项目"
    else:
        s = '您选择了'+s
    LbVar2.set(s)

    
def select_all():
    Check1.select()
    Check2.select()
    Check3.select()
    Check4.select()

def invert():
    Check1.toggle()
    Check2.toggle()
    Check3.toggle()
    Check4.toggle()
        
Lb1 = Label(root,text='请选择您的爱好项目')
Lb1.pack()

checkVar1 = IntVar()
checkVar2 = IntVar()
checkVar3 = IntVar()
checkVar4 = IntVar()
LbVar2 = StringVar()

Check1 = Checkbutton(root,text='足球',variable=checkVar1)
Check1.pack()

Check2 = Checkbutton(root,text='篮球',variable=checkVar2)
Check2.pack()

Check3 = Checkbutton(root,text='游泳',variable=checkVar3)
Check3.pack()

Check4 = Checkbutton(root,text='田径',variable=checkVar4)
Check4.pack()


btnall = Button(root,text='全选',command= select_all)
btnall.place(x=20,y=160)

btninvert = Button(root,text='反选',command = invert)
btninvert.place(x=60,y=160)

btnreset = Button(root,text='重置',command = resetcheck)
btnreset.place(x=100,y=160)

btnok = Button(root,text='确定',command = ok)
btnok.place(x=140,y=160)

Lb2 = Label(root,textvariable=LbVar2)
Lb2.place(x=10,y=210)

root.mainloop()
