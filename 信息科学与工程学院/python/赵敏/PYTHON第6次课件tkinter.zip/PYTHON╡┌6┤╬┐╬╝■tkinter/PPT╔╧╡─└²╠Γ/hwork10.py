# coding=utf-8
from tkinter import *

root = Tk()
root.title("学生信息")
root.geometry("300x300")
L1 = Label(root, text="我班学生信息：")
L1.pack(side=LEFT)#自适应窗口的靠左
E1 = Text(root, bd =5)
E1.pack(side=RIGHT)#自适应窗口的靠右

root.mainloop()

