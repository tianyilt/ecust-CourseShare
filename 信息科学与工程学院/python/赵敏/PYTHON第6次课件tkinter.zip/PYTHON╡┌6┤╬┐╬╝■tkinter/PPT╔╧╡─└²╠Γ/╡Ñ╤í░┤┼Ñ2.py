# !/usr/bin/env python
# coding=utf-8
from tkinter import *
global result
root = Tk()
root.geometry("300x200")

var=IntVar()
val=StringVar()
def cal():
    if var.get()==0:
        result=3*eval(E1.get())
    else:
        result=5*eval(E1.get())
    val="您应该支付：%s元" % result
    L2['text']=val

R1=Radiobutton(root,variable=var,text = '三元套餐',value=0)
R1.pack()
R2=Radiobutton(root,variable=var,text = '五元套餐',value=1)
R2.pack()

L1 = Label(root, text="请输入份数：")
L1.pack()
E1 = Entry(root, bd =5,font=12,width=15)
E1.pack()
B1=Button(root,text='计算 ',command=cal)
B1.pack()

L2 = Label(root, text='')
L2.pack()
root.mainloop()
