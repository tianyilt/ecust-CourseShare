from tkinter import*


x1=int(input("请输入90分以上的人数："))
x2=int(input("请输入80-89分的人数："))
x3=int(input("请输入70-79分以上的人数："))
x4=int(input("请输入60-69分以上的人数："))
x5=int(input("请输入不及格的人数："))


x=[]
x.append(x1)
x.append(x2)
x.append(x3)
x.append(x4)
x.append(x5)
x6=max(x)
x7=400/(x6)
x8=int((x6)/5)+1


root=Tk()
c=Canvas(root,width=700,height=500)


line1=c.create_line(50, 450,600, 450,arrow='last')
line2=c.create_line(50, 450, 50, 30,arrow='last')
line3=c.create_line(50, 370, 53,370,width=2)
line4=c.create_line(50, 290, 53,290,width=2)
line5=c.create_line(50, 210, 53,210,width=2)
line6=c.create_line(50, 130, 53, 130,width=2)
line7=c.create_line(50, 50, 53, 50,width=2)


r1=c.create_rectangle(100,450,150,450-x[0]*x7,fill='red')
r2=c.create_rectangle(200,450,250,450-x[1]*x7,fill='orange')
r3=c.create_rectangle(300,450,350,450-x[2]*x7,fill='yellow')
r4=c.create_rectangle(400,450,450,450-x[3]*x7,fill='green')
r5=c.create_rectangle(500,450,550,450-x[4]*x7,fill='blue')


text1=c.create_text(525,475,text="90")
text2=c.create_text(425,475,text="80")
text3=c.create_text(325,475,text="70")
text4=c.create_text(225,475,text="60")
text5=c.create_text(125,475,text="60<")
text6=c.create_text(590,475,text="marks")
text7=c.create_text(30,20,text="numbers")


text8=c.create_text(125,440-x[0]*x7,text=x1)
text9=c.create_text(225,440-x[1]*x7,text=x2)
text10=c.create_text(325,440-x[2]*x7,text=x3)
text11=c.create_text(425,440-x[3]*x7,text=x4)
text12=c.create_text(525,440-x[4]*x7,text=x5)


text13=c.create_text(30, 370,text=x8)
text14=c.create_text(30, 290,text=2*x8)
text15=c.create_text(30, 210,text=3*x8)
text16=c.create_text(30, 130,text=4*x8)
text17=c.create_text(30, 50,text=5*x8)


c.pack()
root.mainloop()

