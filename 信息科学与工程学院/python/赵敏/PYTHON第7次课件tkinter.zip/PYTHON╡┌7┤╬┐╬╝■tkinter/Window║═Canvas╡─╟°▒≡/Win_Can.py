import tkinter as tk
window=tk.Tk()
window.title('my window')
window.geometry('500x600')
 
cv=tk.Canvas(window,bg='blue',height=500,width=500)#创建一个Canvas，设置其背景色为蓝色，大小为500*500
image_file=tk.PhotoImage(file='001.gif') #打开一张图片
image=cv.create_image(10,10,anchor='nw',image=image_file)#放置着张图片
line=cv.create_line(50,50,80,80) #画一条线，从（50，50）到（80，80）
oval=cv.create_oval(50,50,80,80,fill='red')#画一个红色的圆
arv=cv.create_arc(80,80,100,100,start=0,extent=90)#画个扇形，从0度到90度
rect1=cv.create_rectangle(20,200,110,310,fill='red',outline='green',width = 5)
                #画一个对角坐标（20，20）（110，110）内部红色边框绿色的矩形，边框宽度为5
rect2=cv.create_rectangle(200,10,210,110,outline = 'red',dash = 9)#画虚线dash
rect3=cv.create_rectangle(250,10,300,110,outline = 'red',stipple = 'gray12',fill = 'green')#用画刷填充stipple
 
cv.pack()
 
def moveit():
    cv.move(rect1,1,1)  #移动rect1图形，向右下移动一个像素
b1=tk.Button(window,text='moveit',width=15,height=2,command=moveit)
b1.pack()
 
window.mainloop()
