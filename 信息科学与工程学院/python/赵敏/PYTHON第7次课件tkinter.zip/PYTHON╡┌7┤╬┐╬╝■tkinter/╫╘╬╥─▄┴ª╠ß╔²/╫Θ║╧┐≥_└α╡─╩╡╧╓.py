from tkinter import *
from tkinter.ttk import *
class Ui(Frame):
    def __init__(self,master=None):
        Frame.__init__(self,master)
        self.master.title('四则运算')
        self.master.geometry('320x240')
        self.createWidgets()
    def createWidgets(self):
        self.top=self.winfo_toplevel()
        self.Text1=Entry(self.top)
        self.Text1.place(relx=0.1,rely=0.1,relwidth=0.3,relheight=0.1)
        self.Text2=Entry(self.top)
        self.Text2.place(relx=0.5,rely=0.1,relwidth=0.3,relheight=0.1)
        self.Combo1List=['加','减','乘','除',]
        self.Combo1Var=StringVar(value='加')
        self.Combo1=Combobox(self.top,textvariable=self.Combo1Var,values=self.Combo1List)
        self.Combo1.place(relx=0.1,rely=0.5,relwidth=0.4)
        self.Combo1.bind('<<ComboboxSelected>>',self.calc)
        self.Label1=Label(self.top)
        self.Label1.place(relx=0.5,rely=0.6,relwidth=0.4,relheight=0.2)
class App(Ui):
    def __init__(self,master=None):
        Ui.__init__(self,master)
    def calc(self,event):
        a=float(self.Text1.get())
        b=float(self.Text2.get())
        dic={0:a+b,1:a-b,2:a*b,3:a/b}
        c=dic[self.Combo1.current()]
        self.Label1.config(text=str(c))
if __name__=="__main__":
    root=Tk()
    App(root).mainloop()        
