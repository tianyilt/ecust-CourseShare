from tkinter import *
import tkinter.colorchooser
root = Tk()
def xz():
    color = tkinter.colorchooser.askcolor()
    colorstr = str(color)
    lb.config(text=colorstr[-9:-2],background=colorstr[-9:-2])
lb = Label(root,text='请关注颜色的变化')
lb.pack()
btn = Button(root,text='弹出颜色选择对话框',command=xz)
btn.pack()
root.mainloop()
