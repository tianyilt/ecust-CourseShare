from tkinter import *
def show(event):
    s = '光标位于 x=%s, y=%s' %(str(event.x),str(event.y))
    lb.config(text = s)
root = Tk()
root.title("鼠标实验")
root.geometry("200x200")
lb = Label(root,text='请单击窗体')
lb.pack()
root.bind('<Button-1>',show)
root.mainloop()
