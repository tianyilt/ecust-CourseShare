from tkinter import *
root=Tk()
c=Canvas(root,width=500,height=300,bg='yellow')
r1=c.create_rectangle(150,50,350,250,outline='black',width=5,fill='red')
r2=c.create_rectangle(200,100,300,200,fill='blue')
c.pack()
root.mainloop()
