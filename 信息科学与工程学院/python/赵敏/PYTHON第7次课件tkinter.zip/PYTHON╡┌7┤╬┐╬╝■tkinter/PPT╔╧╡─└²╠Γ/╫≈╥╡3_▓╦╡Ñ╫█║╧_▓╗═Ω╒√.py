#-*- encoding=UTF-8 -*-
__author__ = 'fyby'
from tkinter import *
from random import *
root = Tk()
def easy():
    count1=0
    for i in range(10):
        x=randint(0,10)
        y=randint(0,10)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count1=count1+1
    print("您的得分为:",count1)
    if count1>=8:
        print("恭喜您闯关成功，请进入下一关！")
        
    else:
        print("很遗憾未成功，请重试！")
def medium():
    count2=0
    for i in range(10):
        x=randint(0,100)
        y=randint(0,100)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count2=count2+1
    print("您的得分为:",count2)
    if count2>=8:
        print("恭喜您闯关成功，请进入下一关！")
       
    else:
        print("很遗憾未成功，请重试！")
def hard():
    count3=0
    for i in range(10):
        x=randint(0,1000)
        y=randint(0,1000)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count3=count3+1
    print("您的得分为:",count3)
    if count3>=8:
        print("恭喜您闯关成功，请进入下一关！")
    else:
        print("很遗憾未成功，请重试！")


def about():
    print("张三开发的系统")
menubar = Menu(root)

#创建下拉菜单File，然后将其加入到顶级的菜单栏中
mathmenu = Menu(menubar,tearoff=0)
mathmenu.add_command(label="简单题目", command=easy)
mathmenu.add_command(label="中等题目", command=medium)
mathmenu.add_command(label="困难题目", command=hard)
menubar.add_cascade(label="数学游戏", menu=mathmenu)

#创建下拉菜单Help
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="关于", command=about)
helpmenu.add_separator()
helpmenu.add_command(label="关闭", command=root.destroy)
menubar.add_cascade(label="帮助", menu=helpmenu)

#显示菜单
root.config(menu=menubar)

root.mainloop()
