#-*- encoding=UTF-8 -*-
__author__ = 'fyby'
from tkinter import *
from random import *
from turtle import *
import time
import os
root = Tk()
def easy():
    count1=0
    for i in range(10):
        x=randint(0,10)
        y=randint(0,10)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count1=count1+1
    print("您的得分为:",count1)
    if count1>=8:
        print("恭喜您闯关成功，请进入下一关！")
        
    else:
        print("很遗憾未成功，请重试！")
def medium():
    count2=0
    for i in range(10):
        x=randint(0,100)
        y=randint(0,100)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count2=count2+1
    print("您的得分为:",count2)
    if count2>=8:
        print("恭喜您闯关成功，请进入下一关！")
       
    else:
        print("很遗憾未成功，请重试！")
def hard():
    count3=0
    for i in range(10):
        x=randint(0,1000)
        y=randint(0,1000)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count3=count3+1
    print("您的得分为:",count3)
    if count3>=8:
        print("恭喜您闯关成功，请进入下一关！")
    else:
        print("很遗憾未成功，请重试！")

def draw_liebiao():
    bgcolor("black")
    speed(100)
    sides=6
    colors=["red","yellow","blue","orange","green","purple"]
    for x in range(360):
        pencolor(colors[x%sides])
        forward(x*3/sides+x)
        left(360/sides+1)
        width(x*sides/200)

#画圆的函数
def circle(color,x,y):
    penup()
    pencolor(color)
    goto(x,y)
    pendown()
    for i in range(90):
        right(4)
        forward(4)
    penup()

def draw_wuhuan():
    pensize(10)
    speed(10)
    circle('blue',-150,100)
    circle('black',0,100)
    circle('red',150,100)
    circle('yellow',-75,50)
    circle('green',75,50)

    time.sleep(10) 
    os._exit(1)
        
def draw_bingtu():
    root=Tk()
    x=int(input("请输入90分以上的人数："))
    y=int(input("请输入80-89的人数："))
    z=int(input("请输入70-79的人数："))
    u=int(input("请输入60-69的人数："))
    w=int(input("请输入60分以下的人数："))
    s=x+y+z+w+u
    c=Canvas(root,width=500,height=300,bg='green')
    r1=c.create_arc(0,0,200,200,start=0,extent=float(x)/s*360,fill='red')
    r2=c.create_arc(0,0,200,200,start=float(x)/s*360,extent=float(y)/s*360,fill='blue')
    r3=c.create_arc(0,0,200,200,start=float(x+y)/s*360,extent=float(z)/s*360,fill='yellow')
    r4=c.create_arc(0,0,200,200,start=float(x+y+z)/s*360,extent=float(u)/s*360,fill='white')
    r5=c.create_arc(0,0,200,200,start=float(x+y+z+u)/s*360,extent=float(w)/s*360,fill='black')
    c.pack()
    root.mainloop()


def about():
    print("张三开发的系统")
menubar = Menu(root)

#创建下拉菜单数学游戏，然后将其加入到顶级的菜单栏中
mathmenu = Menu(menubar,tearoff=0)
mathmenu.add_command(label="简单题目", command=easy)
mathmenu.add_command(label="中等题目", command=medium)
mathmenu.add_command(label="困难题目", command=hard)
mathmenu.add_separator()
mathmenu.add_command(label="成绩饼图",command=draw_bingtu)
menubar.add_cascade(label="数学游戏", menu=mathmenu)

#创建下拉菜单画画游戏，然后将其加入到顶级的菜单栏中
drawmenu = Menu(menubar, tearoff=0)
drawmenu.add_command(label="画五环",command=draw_wuhuan)
drawmenu.add_command(label="画不规则列表",command=draw_liebiao)
menubar.add_cascade(label="画画游戏",menu=drawmenu)


#创建下拉菜单帮助
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="关于", command=about)
helpmenu.add_separator()
helpmenu.add_command(label="关闭", command=root.destroy)
menubar.add_cascade(label="帮助", menu=helpmenu)

#显示菜单
root.config(menu=menubar)

root.mainloop()
