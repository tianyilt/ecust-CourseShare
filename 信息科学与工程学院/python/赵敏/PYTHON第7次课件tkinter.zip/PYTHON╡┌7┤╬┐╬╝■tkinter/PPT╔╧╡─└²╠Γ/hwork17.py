from tkinter import *
root=Tk()
c=Canvas(root,width=600,height=600,bg='yellow')
#画红色的坐标轴线
c.create_line(0,300,600,300,fill='red',width=3)
c.create_line(300,0,300,600,fill='red',width=3)
c.pack()
root.mainloop()
