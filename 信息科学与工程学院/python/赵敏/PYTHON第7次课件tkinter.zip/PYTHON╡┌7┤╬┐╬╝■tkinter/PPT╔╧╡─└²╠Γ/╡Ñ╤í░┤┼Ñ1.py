# !/usr/bin/env python
# coding=utf-8
from tkinter import *
root = Tk()
var=IntVar()
def choice():
    if var.get()==0:
        print("您选择了三元套餐")
    else:
        print("您选择了五元套餐")

R1=Radiobutton(root,variable=var,text = '三元套餐',value=0)
R1.pack()
R2=Radiobutton(root,variable=var,text = '五元套餐',value=1)
R2.pack()
B1=Button(root,text='选择 ',command=choice)
B1.pack()

root.mainloop()
