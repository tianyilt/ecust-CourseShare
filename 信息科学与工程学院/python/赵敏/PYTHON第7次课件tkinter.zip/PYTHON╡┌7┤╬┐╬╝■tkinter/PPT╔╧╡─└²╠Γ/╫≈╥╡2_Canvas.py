﻿from tkinter import *
import math
root = Tk()
w = Canvas(root, width=600, height=600)
w.pack()
# 画红色的坐标轴线
width=600
height=600
wh=width/2
hh=height/2
w.create_line(0, hh, width, hh, fill="red")
w.create_line(wh, 0, wh, height, fill="red")

def x(t):
    x = wh/2*(pow((math.cos(5/2*t)),3)+math.sin(t))*math.cos(t)
    x+=wh    #平移x轴
    return x
def y(t):
    y = hh/2*(pow((math.cos(5/2*t)),3)+math.sin(t))*math.sin(t)
    y-=hh    #平移y轴
    y = -y    #y轴值反向
    return y
t = 0
while(t<4*math.pi):
    w.create_line(x(t), y(t), x(t+0.01), y(t+0.01),fill="blue")
    t+=0.01
root.mainloop()
