import hwork23
print(hwork23.C)
