from tkinter import *
root = Tk()
root.title("列表框实验")
root.geometry("320x240")

def init():
    Lstbox1.delete(0,END)
    listitem = ['数学','物理','化学','语文','外语']
    for i in listitem:
        Lstbox1.insert(END,i)

def ins():
    if entry1.get()!='':
        if Lstbox1.curselection()==():
            Lstbox1.insert(END,entry1.get())
        else:
            Lstbox1.insert(Lstbox1.curselection(),entry1.get())

def updt():
    if entry1.get()!='' and Lstbox1.curselection()!=():
        selet = Lstbox1.curselection()
        Lstbox1.delete(selet)
        Lstbox1.insert(selet,entry1.get())
 
def delt():
    if Lstbox1.curselection()!=():
        Lstbox1.delete(Lstbox1.curselection())    

def clear():
    Lstbox1.delete(0,END)

frame1 = Frame(root,relief = RAISED)
frame1.place(relx=0.0)

frame2 = Frame(root,relief = GROOVE)
frame2.place(relx=0.5)

Lstbox1 = Listbox(frame1)
Lstbox1.pack()

entry1 = Entry(frame2)
entry1.pack()
btn1 = Button(frame2,text='初始化',command=init)
btn1.pack(fill=X)
btn2 = Button(frame2,text='添加',command=ins)
btn2.pack(fill=X)
btn3 = Button(frame2,text='插入',command=ins)
btn3.pack(fill=X)
btn4 = Button(frame2,text='修改',command=updt)
btn4.pack(fill=X)
btn5 = Button(frame2,text='删除',command=delt)
btn5.pack(fill=X)
btn6 = Button(frame2,text='清空',command=clear)
btn6.pack(fill=X)

root.mainloop()
