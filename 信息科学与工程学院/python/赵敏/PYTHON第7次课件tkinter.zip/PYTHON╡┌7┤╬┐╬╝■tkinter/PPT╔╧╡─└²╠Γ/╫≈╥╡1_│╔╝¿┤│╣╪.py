#-*- encoding=UTF-8 -*-
__author__ = 'fyby'
from tkinter import *
from random import *
root = Tk()
root.title("数字闯关游戏")
root.geometry("300x330")
def easy():
    count1=0
    for i in range(10):
        x=randint(0,10)
        y=randint(0,10)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count1=count1+1
    print("您的得分为:",count1)
    if count1>=8:
        print("恭喜您闯关成功，请进入下一关！")
        
    else:
        print("很遗憾未成功，请重试！")
def medium():
    count2=0
    for i in range(10):
        x=randint(0,100)
        y=randint(0,100)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count2=count2+1
    print("您的得分为:",count2)
    if count2>=8:
        print("恭喜您闯关成功，请进入下一关！")
       
    else:
        print("很遗憾未成功，请重试！")
def hard():
    count3=0
    for i in range(10):
        x=randint(0,1000)
        y=randint(0,1000)
        print(x,'+',y,'=')
        answer=int(input("your answer is:"))
        if x+y==answer:
            count3=count3+1
    print("您的得分为:",count3)
    if count3>=8:
        print("恭喜您闯关成功，请进入下一关！")
    else:
        print("很遗憾未成功，请重试！")

    
#简单题目
c1=Button(root,text='简单题目',font =('黑体','20','bold'),height=2,width=15,command=easy,bg='red',fg='yellow')
c1.place(x=30,y=20)

#中等题目
c1=Button(root,text='中等题目',font =('黑体','20','bold'),height=2,width=15,command=medium,bg='blue',fg='white')
c1.place(x=30,y=120)

#困难题目
c1=Button(root,text='困难题目',font =('黑体','20','bold'),height=2,width=15,command=hard,bg='yellow',fg='black')
c1.place(x=30,y=220)

root.mainloop()
