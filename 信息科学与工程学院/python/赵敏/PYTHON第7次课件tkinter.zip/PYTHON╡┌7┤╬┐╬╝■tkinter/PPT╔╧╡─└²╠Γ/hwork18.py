from tkinter import *
root=Tk()
c=Canvas(root,width=250,height=200,bg='yellow')
c.create_arc(50,50,200,200,start=0,extent=120,fill='red')
c.pack()
root.mainloop()
