# coding=utf-8
from tkinter import *
from tkinter.messagebox import *
def mumcall():
   showinfo( "爱的表达", "妈妈，我爱你")
def dadcall():
   showinfo( "爱的表达", "爸爸，我爱你")
root=Tk()
btn_Mum=Button(root, 
                        text='妈妈',             #指定按钮上的文本
                        width=40,               #指定按钮宽度，相当于40个字符
                        height=5,               #指定按钮高度，相当于5个字符
                        bg='red',               #指定按钮背景色
                        command=mumcall         #绑定事件
                        )
btn_Mum.pack()#pack是tkinter中的一个布局管理模块
btn_Dad=Button(root, 
                        text='爸爸',             #指定按钮上的文本
                        width=40,               #指定按钮宽度，相当于40个字符
                        height=5,               #指定按钮高度，相当于5个字符
                        bg='blue',              #指定按钮背景色
                        command=dadcall         #绑定事件
                        )
btn_Dad.pack()
btn_Quit=Button(root,
                          
                          text='退出',          #指定按钮上的文本
                          width=40,             #指定按钮宽度，相当于40个字符
                          height=5,             #指定按钮高度，相当于5个字符
                          bg='yellow',          #指定按钮背景色
                          command=root.destroy     #删除事件，被禁用
                          )
btn_Quit.pack()
root.mainloop()
