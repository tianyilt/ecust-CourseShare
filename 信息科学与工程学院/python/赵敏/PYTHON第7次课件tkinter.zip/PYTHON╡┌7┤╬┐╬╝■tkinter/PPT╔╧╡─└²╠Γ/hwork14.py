from tkinter import *
root=Tk()
c=Canvas(root,width=500,height=300,bg='yellow')
c.pack()
root.mainloop()
