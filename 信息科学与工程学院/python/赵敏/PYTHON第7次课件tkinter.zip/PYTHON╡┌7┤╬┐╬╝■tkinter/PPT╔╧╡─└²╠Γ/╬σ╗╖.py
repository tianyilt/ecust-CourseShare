import time
import os
import turtle
def circle(color,x,y):
    turtle.penup()
    turtle.pencolor(color)
    turtle.goto(x,y)
    turtle.pendown()
    for i in range(90):
        turtle.right(4)
        turtle.forward(4)
    turtle.penup()

turtle.pensize(10)
turtle.speed(10)
circle('blue',-150,100)
circle('black',0,100)
circle('red',150,100)
circle('yellow',-75,50)
circle('green',75,50)

time.sleep(10) 
os._exit(1)
