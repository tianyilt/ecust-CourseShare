# coding=utf-8
from tkinter import *
def openfile():
    fobj=open('student.txt','r')
    for i in fobj:
        E1.insert(INSERT,i)#INSERT索引表示在光标处插入
    fobj.close()
root = Tk()
root.title("学生信息")
root.geometry("300x300")
L1 = Label(root, text="我班学生信息：")
L1.place(x=10,y=100)
E1 = Text(root, bd =5,height=20,width=30)
E1.place(x=100,y=0)
B1=Button(root,text='导入学生信息',command=openfile)
B1.place(x=10,y=250)
root.mainloop()

