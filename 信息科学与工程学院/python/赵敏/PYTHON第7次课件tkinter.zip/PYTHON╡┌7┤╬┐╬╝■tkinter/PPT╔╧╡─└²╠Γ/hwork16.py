from tkinter import *
root=Tk()
c=Canvas(root,width=500,height=300,bg='yellow')
r1=c.create_oval(100,50,400,250,fill='red')
r2=c.create_oval(150,100,350,200,fill='blue')
c.pack()
root.mainloop()
