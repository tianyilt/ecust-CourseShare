from tkinter import *
root = Tk()
c=Canvas(root,width=300,height=200,bg='yellow')
pic=PhotoImage(file='dog2.gif')
t=c.create_image(200,100,image=pic)
c.pack()
root.mainloop()
