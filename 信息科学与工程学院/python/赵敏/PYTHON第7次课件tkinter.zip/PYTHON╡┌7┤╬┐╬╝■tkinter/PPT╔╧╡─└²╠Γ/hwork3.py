# coding=utf-8
from tkinter import *
import tkinter.messagebox
root = Tk()
root.title("评分游戏")
root.geometry("300x300")
def start():
    tkinter.messagebox.showinfo( "Hello Python", "Start Game！")
def quit():
    root.destroy() #root.quit()的区别

aLabel = Label(root,text="欢迎进入评分游戏",font='隶书 20',width=20,height=5,fg='red')
aLabel.place(x=10,y=10)

#开始按钮
c1=Button(root,text='开始游戏',font ='20',height=2,width=22,command=start)
c1.place(x=30,y=150)

#退出按钮
c1=Button(root,text='退出游戏',font ='20',height=2,width=22,state=NORMAL,command=quit)
c1.place(x=30,y=200)

root.mainloop()

