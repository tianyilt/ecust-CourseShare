from tkinter import *
root=Tk()
c=Canvas(root,width=300,height=150,bg='yellow')
r1=c.create_polygon(70,20,35,50,55,85,85,85,105,50,fill='red')
r2=c.create_polygon(170,20,155,85,205,50,135,50,185,85,fill='blue')
c.pack()
root.mainloop()
