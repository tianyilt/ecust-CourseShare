# !/usr/bin/env python
# coding=utf-8
from tkinter import *
def callCheckbutton():
    print("恭喜测试成功")
root = Tk()
root.geometry("200x200")
C1=Checkbutton(root,text = '测试一下',command = callCheckbutton)
C1.pack()
root.mainloop()
