C=0  #在文件开头声明全局变量
def modifyConstant() :
    global C
    print(C)
    C+=5
    return

if __name__ == '__main__' :
    modifyConstant()
    print(C)
