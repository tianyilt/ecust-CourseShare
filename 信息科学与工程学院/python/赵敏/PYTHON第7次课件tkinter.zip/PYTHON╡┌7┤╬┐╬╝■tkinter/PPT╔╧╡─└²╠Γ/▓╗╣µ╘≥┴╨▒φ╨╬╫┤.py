from turtle import *
bgcolor("black")
speed(100)
sides=6
colors=["red","yellow","blue","orange","green","purple"]
for x in range(360):
    pencolor(colors[x%sides])
    forward(x*3/sides+x)
    left(360/sides+1)
    width(x*sides/200)
