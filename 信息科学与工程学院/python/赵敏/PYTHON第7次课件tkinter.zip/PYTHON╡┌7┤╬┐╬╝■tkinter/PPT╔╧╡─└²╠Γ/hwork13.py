#-*- encoding=UTF-8 -*-

from tkinter import *
root = Tk()
menubar = Menu(root)
# create a pulldown menu, and add it to the menu bar
#将tearoff设置为1以后，就是表明这个菜单是可以独立出来的，点击虚线就可以独立出来
mathmenu = Menu(menubar,tearoff=1)
mathmenu.add_command(label="简单题目")
mathmenu.add_command(label="中等题目")
mathmenu.add_command(label="困难题目")
menubar.add_cascade(label="数学游戏", menu=mathmenu)
# create more pulldown menus
drawmenu = Menu(menubar, tearoff=0)
drawmenu.add_command(label="画五环")
drawmenu.add_command(label="画不规则列表")
menubar.add_cascade(label="画画游戏",menu=drawmenu)

helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="关于")
helpmenu.add_separator()
helpmenu.add_command(label="关闭")
menubar.add_cascade(label="帮助", menu=helpmenu)
#显示菜单
root.config(menu=menubar)
root.mainloop()
