# coding=utf-8
from tkinter import *
root = Tk()
root.title("评分游戏")
root.geometry("300x300")

aLabel = Label(root,text="欢迎进入评分游戏",font='隶书 20',width=20,height=5,fg='red')
aLabel.place(x=10,y=10)

#开始按钮
c1=Button(root,text='开始游戏',font ='20',height=2,width=22)
c1.place(x=30,y=150)

#退出按钮
c1=Button(root,text='退出游戏',font ='20',height=2,width=22)
c1.place(x=30,y=200)

root.mainloop()

