from tkinter import *
root = Tk()
c=Canvas(root,width=300,height=200,bg='yellow')
t=c.create_text(100,100,text='I love China!',font=('Times',20),fill='red')
c.pack()
root.mainloop()
