#coding=utf-8
from tkinter import *
from tkinter.messagebox import *
def verify():
    if(E1.get()=='admin' and E2.get()=='123456'):
        print("密码正确，欢迎进入")
    else:
        print([E1.get(),E2.get()])
        print("密码错误，请重试")

root = Tk()
root.title("密码验证")
root.geometry("250x150")

L1 = Label(root, text="用户名：")
L1.place(x=10,y=10)

E1 = Entry(root, bd =5,font=12,width=15)
E1.place(x=60,y=10)
L2=Label(root, text="密   码：")
L2.place(x=10,y=60)

E2 = Entry(root, bd =5,font=12,width=15,show='*')
E2.place(x=60,y=60)
B1 = Button(root, text="验证密码信息",width=15,command=verify)
B1.place(x=70,y=100)
root.mainloop()
