from tkinter import *
from tkinter.ttk import *#ttk引入，更好的使用Combobox
root = Tk()
root.title("四则运算")
root.geometry("320x240")

def calc(event):
    a = float(entry1.get())
    b = float(entry2.get())
    dic = {0:a+b,1:a-b,2:a*b,3:a/b}
    c = dic[comb1.current()]
    label1.config(text=str(c))

entry1 = Entry(root)
entry1.place(relx=0.1,rely=0.1,relwidth=0.2,relheight=0.1)

entry2 = Entry(root)
entry2.place(relx=0.5,rely=0.1,relwidth=0.2,relheight=0.1)

comb1 = Combobox(root,values=['加','减','乘','除'])
comb1.place(relx=0.1,rely=0.5,relwidth=0.2)
comb1.bind('<<ComboboxSelected>>',calc)

label1 = Label(root,text = '结果')
label1.place(relx=0.5,rely=0.7,relwidth=0.2,relheight=0.3)

root.mainloop()
