# !/usr/bin/env python
# coding=utf-8
from tkinter import *
def callCheckbutton():
    #改变v的值，即改变Checkbutton的显示值
    v.set('I love China!')

root = Tk()
v = StringVar()
v.set('我爱中国')
#绑定v到Checkbutton的属性textvariable
C1=Checkbutton(root,textvariable = v,command = callCheckbutton)
C1.pack()
root.mainloop()
