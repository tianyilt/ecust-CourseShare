#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<errno.h>
#include<sys/wait.h>
#include<stdio.h>
void main(){
	int tkpid;
	void go();//继续开车 
	void door();//打开车门
	if(tkpid=fork())//父进程 
	{
		signal(SIGUSR1,go);//收到信号一执行go
		printf("bus moves... on the way\n");
		sleep(3);
		printf("bus has stopped\n");
		kill(tkpid,SIGUSR1);//杀死父进程,发送信号一
		sleep(10);
		exit(0);
	} 
	else//子进程 
	{
		signal(SIGUSR1,door);
		sleep(5);
		exit(0);
	}
}

void door(){
	printf("open the door\n");
	sleep(1);
	printf("close the door\n");
	kill(getppid(),SIGUSR1);//杀死子进程,发送信号一
}

void go()
{
	printf("door closed, ready to go\n");
}
