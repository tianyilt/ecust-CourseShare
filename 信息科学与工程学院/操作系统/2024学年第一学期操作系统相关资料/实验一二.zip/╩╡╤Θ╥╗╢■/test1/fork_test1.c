#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main(){
	int pid;
	pid=fork();//创建子进程
	switch(pid){
		case -1:
			printf("fork failed:\n");
			exit(1);
		case 0:
			sleep(10);
			printf("This is the son:\n");
			execl("/bin/ls","ls","-l",NULL);
			printf("exec failed:\n");
			exit(1);
		default:
			wait(0);
			printf("This is the father:\n");
			while(1)	sleep(1);
			exit(0);
	} 
}
