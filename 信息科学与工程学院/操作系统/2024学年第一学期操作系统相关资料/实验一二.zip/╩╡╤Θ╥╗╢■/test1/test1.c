#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
   pid_t pid1, pid2;
   while ((pid1 = fork()) == -1);
    //在子进程中，fork返回0
   if (pid1 == 0) printf("b\n");
   else
   {
      while ((pid2 = fork()) == -1);
      if (pid2 == 0) printf("c\n");
      else printf("a\n");
   }
   return 0;
}

