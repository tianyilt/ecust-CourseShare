#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<errno.h>
#include<sys/wait.h>
#include<stdio.h>

int main(){

        pid_t childpid; 
        int retval;    
        int status;

        //使用系统调用fork( )创建一个子进程
        childpid = fork();
        if (childpid >= 0) {
                if (childpid == 0) {
                        printf("Child:I am the child process\n");
                        printf("Child:My PID is %d\n",getpid());
                        printf("Child:My parent's PID is %d\n",getppid());
                        printf("Child:Sleep for 10 second...\n");
                        sleep(10);
			     //retval指针：如果需要传递指针，必须指向全局、堆，不能指向栈。
                        scanf("%d",&retval);
                        exit(retval);             
               }
                else {
                        printf("Parent:The value of my child's PID is %d\n", childpid);
                        wait(&status);
                        printf("Parent:Child's exit code is %d\n",WEXITSTATUS(status));
                        exit(0);
                }

        }
        else {
                perror("fork error\n");
                exit(0);
        }

        return 0;
}
/*
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<errno.h>
#include<sys/wait.h>
#include<stdio.h>

int main(){

        pid_t childpid; 
        int retval;    
        int status;    

        childpid = fork()
        if (childpid >= 0) {
                if (childpid == 0) {
                        printf("Child:I am the child process\n");
                        printf("Child:My PID is %d\n",getpid());
                        printf("Child:My parent's PID is %d\n",getppid());
                        printf("Child:The value of fork return is %d\n",childpid);
                        printf("Child:Sleep for one second...\n");
                        sleep(1);
                        printf("Child:Enter an exit value (0~255): ");
                        scanf("%d",&retval);
                        printf("Child:Goodbye! \n");
                        exit(retval);             
               }
                else {
                        printf("Parent:I am the parent process!\n");
                        printf("Parent:My PID is %d\n",getpid());
                        printf("Parent:The value of my child's PID is %d\n", childpid);
                        printf("Parent:I will now wait for my child to exit.\n");
                        wait(&status);
                        printf("Parent:Child's exit code is %d\n",WEXITSTATUS(status));
                        printf("Parent:Goodbye!\n");
                        exit(0);

                }

        }
        else {
                perror("fork error\n");
                exit(0);
        }

        return 0;
}

*/
