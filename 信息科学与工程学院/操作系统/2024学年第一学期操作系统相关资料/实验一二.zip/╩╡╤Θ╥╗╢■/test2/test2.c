#include <stdio.h>
#include <pthread.h>
#include <unistd.h> 
#include <sys/syscall.h>

typedef struct{
	char name[20];
	int number;
}Student;

void *create(void *x){
	Student student = *(Student *)x;
	printf("%s %d\n",student.name,student.number);
	return (void*)0;
}

int main(int argc,char *argv[])
{
	pthread_t tid;
	int error;
	Student student={"小田",114514};

	error=pthread_create(&tid,NULL,create,(void *)&student);
	sleep(1);

	return 0; 
}
