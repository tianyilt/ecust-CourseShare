#include <stdio.h>
#include <pthread.h>
#include <sys/syscall.h>

 
void* Func_pth1()
{
	printf("child gettid = %u\n", syscall(SYS_gettid));
	printf("child pthread_self= %u\n", (unsigned int)pthread_self());
}
 
int main()
{
	int iRet = 0;
	pthread_t pth1;
	printf("main gettid = %u\n", syscall(SYS_gettid));
	printf("main pthread_self = %u\n", (unsigned int)pthread_self());
	iRet = pthread_create(&pth1, NULL, (void*)Func_pth1, NULL);//创建线程 
	if(iRet)
	{
		printf("create pthread fail\n");
	}
	pthread_join(pth1, NULL);
	 
	return 0;
}
// 编译方法：gcc xxxx.c -o xxxx -lpthread 
