#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#define nLOOP 10

//pthread_mutex_t mylock;
int counter=0; //共享变量

void *thread_func(void *vptr)
{
	//pthread_mutex_lock(&mylock);
	int i,val;
	for(i=0;i<nLOOP;i++)
	{
		val=counter;
		sleep((unsigned long)vptr);
		counter=val+1;
		printf("0x%x: %d\n",(unsigned int)pthread_self(),counter);
	}
	//pthread_mutex_unlock(&mylock); //解锁
	return NULL;
}
int main(int argc,char **argv)
{
	//int ret;
	//ret = pthread_mutex_init(&mylock, NULL);//初始化锁 
	//if (ret != 0){
		//printf("mutex init failed\n");
		//return -1;
	//}
	
	pthread_t tid1,tid2;
	pthread_create(&tid1,NULL,thread_func,(void *)1);
	pthread_create(&tid2,NULL,thread_func,(void *)2);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	printf("main thread: counter=%d\n",counter);
	
	//pthread_mutex_destroy(&mylock);//摧毁锁 
	return 0;
}

