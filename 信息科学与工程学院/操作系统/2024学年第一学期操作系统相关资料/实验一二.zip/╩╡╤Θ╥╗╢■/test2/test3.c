#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
 
void *thread1(void *arg);
sem_t sem;
int i=0;

int main()
{
	pthread_t id1;
	sem_init(&sem,0,0);
	pthread_create(&id1,NULL,thread1,NULL);
	while(1)
	{
		sem_wait(&sem);
		printf("main thread:%d\n",i++);
		if(i>30)break;
	}
	pthread_join(id1,NULL);
	return 0;
}

void *thread1(void *arg)
{
	while(1)
	{
		printf("son thread:%d\n",i++);
		sem_post(&sem);
		sleep(1);
		if(i>30)break;
	}
	pthread_exit(0);
}

