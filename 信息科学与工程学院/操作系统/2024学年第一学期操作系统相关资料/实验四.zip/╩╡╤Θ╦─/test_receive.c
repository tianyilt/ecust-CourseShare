#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/ipc.h>

struct msgData
{
    long mtype;
    char mtext[64];
};

int main(int argc, char *argv[])
{
    key_t key;
    key = ftok(".", 10);
    int messageID;
    messageID = msgget(key , IPC_CREAT|0666);   
    struct msgData buf;   
    pid_t pid = fork();

    if(pid > 0)
    {
        printf("This is p_2.\n");
        while(1)
        {
            memset(buf.mtext,0,sizeof(buf.mtext));
            msgrcv(messageID,&buf,64,1,0);//从队列中读标识是1的信息
            printf("receive from p_1:%s",buf.mtext);           
            if(strncmp(buf.mtext,"quit",4) == 0)//收到quit后，杀掉子进程，之后退出
            {
                kill(pid,SIGKILL);
                break;
            }
        }
        wait(NULL);
    }
    
    if(pid == 0)//子进程持续发信息
    {
        while(1)
        {
            memset(buf.mtext,0,sizeof(buf.mtext));            
            buf.mtype = 2;//写标识是2的信息进队列
            fgets(buf.mtext,64,stdin);
            msgsnd(messageID,&buf,strlen(buf.mtext),0);
            if(strncmp(buf.mtext,"quit",4) == 0)//发送quit后，杀掉父进程，之后退出
            {
                kill(getppid(),SIGKILL);
                break;
            }
        }
    }
    //删除队列消息
    msgctl(messageID, IPC_RMID, NULL);
    return 0;
}




