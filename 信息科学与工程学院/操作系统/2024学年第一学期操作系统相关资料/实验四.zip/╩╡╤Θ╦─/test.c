#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/ipc.h>

struct msgData			//定义消息结构体
{
    long mtype;			    //消息的标识，必须是long类型
    char mtext[64];		    //消息的正文
};

int main(int argc, char *argv[])
{
    key_t key;              //定义key值
    key = ftok(".", 10);    
    int messageID;
    messageID = msgget(key , IPC_CREAT|0666);   //根据key值申请消息队列ID号 int msgget(key_t key, int msgflg);    
    struct msgData data;   
    pid_t pid = fork();     //创建子进程
    
    if(pid > 0)             //父进程持续发信息
    {
        printf("This is p_1.\n");
        while(1)
        {
            memset(data.mtext,0,sizeof(data.mtext));           
            data.mtype = 1;     //写标识是1的信息进队列
            fgets(data.mtext,64,stdin);     // char *fgets(char *str, int n, FILE *stream) 从指定的流 stream 读取一行，并把它存储在 str 所指向的字符串内
            msgsnd(messageID,&data,strlen(data.mtext),0);   //向消息队列发送数据 int msgsnd(int msqid, const void *msgp, size_t msgsz, int msgflg);            
            if(strncmp(data.mtext,"quit",4) == 0)           //发送quit后，杀掉子进程，之后退出
            	{
                kill(pid,SIGKILL);
                break;
            	}
        }
        wait(NULL);
    }
    
    if(pid == 0)//子进程持续读信息
    {
        while(1)
        {
            memset(data.mtext,0,sizeof(data.mtext));
            msgrcv(messageID,&data,64,2,0);//从队列中读标识是2的信息
            printf("receive from p_2:%s",data.mtext);           
            if(strncmp(data.mtext,"quit",4) == 0)//收到quit，kill掉父进程之后退出
           	{
                kill(getppid(),SIGKILL);
                break;
            	}
        }
    }
    
    msgctl(messageID, IPC_RMID, NULL);//删除队列信息
    return 0;
}

